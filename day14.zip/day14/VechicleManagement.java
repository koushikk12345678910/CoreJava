package day14;


class Vechicle
{
	void startengine() {
		System.out.println("vechicle engine started");
	}
}
class car extends Vechicle
{
	void drive() {
		System.out.println("car is driving");
	}
}
class ElectricCar extends car
{
	void chargbattery() {
		System.out.println("elctric car is charging");
	}
}
class bike extends Vechicle{
	void kickstart()
	{
		System.out.println("the bike is kick started");
	}
}








public class VechicleManagement {
	public static void main(String[] args) {
		ElectricCar c=new ElectricCar();
		c.startengine();
		c.drive();
		c.chargbattery();
		bike b=new bike();
		b.startengine();
		b.kickstart();
				
		
	}

}
