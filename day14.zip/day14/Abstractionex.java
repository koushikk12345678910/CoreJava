package day14;

  abstract class calc
{
	public abstract void add(int a,int b);
	public abstract void sub(int a,int b);
	public abstract void multiply(int a,int b);
	void divide(int a,int b)
	{
		System.out.println("division :"+(a/b));
	}
}


public class Abstractionex  extends calc{
	
	public void add(int a,int b)
	{
		System.out.println("addition :"+(a+b));
	}

	public void sub(int a,int b)
	{
		System.out.println("subtraction :"+(a-b));
	}
	public void multiply(int a,int b)
	{
		System.out.println("multiplication :"+(a*b));
	}
	
	
	public static void main(String[] args) {
		Abstractionex  c=new Abstractionex ();
		c.add(10,50 );
		c.sub(60, 14);
		c.multiply(60, 10);
		c.divide(45, 8);
		
	}

}
