package day11;

import java.util.Scanner;

public class MethodForm {
	public static void main(String[] args) {
		EmployeeOops a=new EmployeeOops();
		a.id=1;
		a.name="ajay";
		a.phoneNO=9840564788l;
		a.fees=20000;
		
		a.device();
		
		EmployeeOops b=new EmployeeOops();
		b.id=2;
		b.name="rahul";
		b.phoneNO=9840565555l;
		b.fees=25000;
		
		b.device();
		
		Scanner sc=new Scanner(System.in);
		EmployeeOops c=new EmployeeOops();
		System.out.println("enter the employee id\t\t:");
		c.id=sc.nextInt();
		System.out.println("enter the employee name\t\t:");
		c.name =sc.next();
		System.out.println("enter the employee phoneNO\t\t:");
		c.phoneNO =sc.nextLong();
		System.out.println("enter the employee salary\t\t:");
		c.fees =sc.nextInt();
		
		
	c.device();
	}


}
