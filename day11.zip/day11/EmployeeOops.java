package day11;



public class EmployeeOops {
	
	int id;
	String name;
	long phoneNO;
	int fees;
	
		void device()
		{
			System.out.println("student id\t:"+id);
			System.out.println("student name\t:"+name);
			System.out.println("student phoneNo\t:"+phoneNO);
			System.out.println("student fees\t:"+fees);
		}
	
	
	
}
