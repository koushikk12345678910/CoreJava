package day8;

import java.util.Scanner;

public class ArrayIndex {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
		String arr[]= {"apple","ornge","banana"};
	System.out.println(arr[0]);
		
		
		
		System.out.println("enter the array integer\t:");
		
		int array[]=new int[5];
		
		
		array[0] = sc.nextInt();
		array[1] = sc.nextInt();
		array[2] = sc.nextInt();
		array[3] = sc.nextInt();
		array[4] = sc.nextInt();
		
		
		for(int i=0;i<array.length;i++)
		{
			System.out.println(array[i]);
		}
		
	}

}
