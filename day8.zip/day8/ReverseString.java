package day8;

import java.util.Scanner;

public class ReverseString {
public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
	  String rs="";
	 System.out.println("enter the words\t\t:");
	String word=sc.next();
	String str=word.trim();
	
	for(int i=str.length()-1;i>=0;i--)
	{
		rs=rs+str.charAt(i);
	}
	System.out.println(rs);
	if(str==rs)
	{
		System.out.println("palimdrome");
	}
	else {
		System.out.println("not a palidrome");
	}

	
	
}
}
