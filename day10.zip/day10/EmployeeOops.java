package day10;

import java.util.Scanner;

public class EmployeeOops {
	
	int id;
	String name;
	long phoneNO;
	int salary;
	
	public static void main(String[] args) {
		EmployeeOops a=new EmployeeOops();
		a.id=1;
		a.name="ajay";
		a.phoneNO=9840564788l;
		a.salary=20000;
		
		System.out.println("employee id  :"+a.id);
		System.out.println("employee name  :"+a.name);
		System.out.println("employee phone number  :"+a.phoneNO);
		System.out.println("employee salary  :"+a.salary);
		
		EmployeeOops b=new EmployeeOops();
		b.id=2;
		b.name="rahul";
		b.phoneNO=9840565555l;
		b.salary=25000;
		
		System.out.println("employee id  :"+b.id);
		System.out.println("employee name  :"+b.name);
		System.out.println("employee phone number  :"+b.phoneNO);
		System.out.println("employee salary  :"+b.salary);
		
		Scanner sc=new Scanner(System.in);
		EmployeeOops c=new EmployeeOops();
		System.out.println("enter the employee id\t\t:");
		c.id=sc.nextInt();
		System.out.println("enter the employee name\t\t:");
		c.name =sc.next();
		System.out.println("enter the employee phoneNO\t\t:");
		c.phoneNO =sc.nextLong();
		System.out.println("enter the employee salary\t\t:");
		c.salary =sc.nextInt();
		
		
		System.out.println("employee id  :"+c.id);
		System.out.println("employee name  :"+c.name);
		System.out.println("employee phone number  :"+c.phoneNO);
		System.out.println("employee salary  :"+c.salary);
	}

}
