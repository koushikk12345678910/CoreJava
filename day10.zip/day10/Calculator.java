package day10;

import java.util.Scanner;

public class Calculator {
	
	public   void add(int a,int b)
	{
		System.out.println("addition\t\t:"+(a+b));
	}
	public  void subtract(int a,int b)
	{
		System.out.println("subtraction\t\t:"+(a-b));
	}
	public  void multiply(int a,int b)
	{
		System.out.println("multiplication\t\t:"+(a*b));
	}
	public  void division(int a,int b)
	{
		System.out.println("division\t\t:"+(a/b));
	}
	
	
public static void main(String[] args) {
	Calculator cals=new Calculator();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number\t\t:");
	int a=sc.nextInt();
	System.out.println("enter the number\t\t:");
	int b=sc.nextInt();
	cals.add(a,b);
	cals.subtract(a,b);
	cals.multiply(a,b);
	cals.division(a,b);
}
}
